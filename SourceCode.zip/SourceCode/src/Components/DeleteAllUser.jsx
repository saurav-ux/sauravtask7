import React from 'react'

function DeleteAllUser() {
  return (
    <div>
      DeleteAll user
    </div>
  )
}

export default DeleteAllUser

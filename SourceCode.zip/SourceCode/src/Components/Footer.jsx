import React from 'react'

function Footer() {
  return (
    <div>
       <div className='footer'>
            <p className='foot'>Copyright &copy; Saurav Anand | Website Design & SEO Sanand Checkpoint.</p>
        </div>
    </div>
  )
}

export default Footer
